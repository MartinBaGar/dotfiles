# fbterm

This plugin automatically starts [fbterm](https://github.com/zhangyuanwei/fbterm)
if on a real TTY (`/dev/tty*`).

To use it, add `fbterm` to the plugins array of your zshrc file:

```zsh
plugins=(... fbterm)
```
